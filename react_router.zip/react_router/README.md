# react-router-4-example
This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app) and it's the sample project of a beginners guide to [React Router DOM](https://reacttraining.com/react-router/web/guides/philosophy).

You can read the guide on [LogRocket's blog](https://blog.logrocket.com/) (not yet published).

## Instructions 
1. Clone this project.
2. Install the dependencies with `npm install`.
3. Execute `npm start` to run the application.

## License
MIT